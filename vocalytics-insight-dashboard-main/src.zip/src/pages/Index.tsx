
import { Navigate } from "react-router-dom";

const Index = () => <Navigate to="/agents" replace />;

export default Index;
